package android.arch.lifecycle.livedata.core;

public final class R {}


/* Location:              C:\Users\mikel\Desktop\Projects\LEDStripController\HappyLighting_base-dex2jar.jar!\android\arch\lifecycle\livedata\core\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */