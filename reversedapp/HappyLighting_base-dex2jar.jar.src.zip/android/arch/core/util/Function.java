package android.arch.core.util;

public interface Function<I, O> {
  O apply(I paramI);
}


/* Location:              C:\Users\mikel\Desktop\Projects\LEDStripController\HappyLighting_base-dex2jar.jar!\android\arch\cor\\util\Function.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */