package android.support.v7.recyclerview;

public final class R {
  public static final class attr {
    public static final int fastScrollEnabled = 2130903173;
    
    public static final int fastScrollHorizontalThumbDrawable = 2130903174;
    
    public static final int fastScrollHorizontalTrackDrawable = 2130903175;
    
    public static final int fastScrollVerticalThumbDrawable = 2130903176;
    
    public static final int fastScrollVerticalTrackDrawable = 2130903177;
    
    public static final int layoutManager = 2130903211;
    
    public static final int reverseLayout = 2130903316;
    
    public static final int spanCount = 2130903328;
    
    public static final int stackFromEnd = 2130903334;
  }
  
  public static final class dimen {
    public static final int fastscroll_default_thickness = 2131099737;
    
    public static final int fastscroll_margin = 2131099738;
    
    public static final int fastscroll_minimum_range = 2131099739;
    
    public static final int item_touch_helper_max_drag_scroll_per_frame = 2131099747;
    
    public static final int item_touch_helper_swipe_escape_max_velocity = 2131099748;
    
    public static final int item_touch_helper_swipe_escape_velocity = 2131099749;
  }
  
  public static final class id {
    public static final int item_touch_helper_previous_elevation = 2131230945;
  }
  
  public static final class styleable {
    public static final int[] RecyclerView = new int[] { 
        16842948, 16842993, 2130903173, 2130903174, 2130903175, 2130903176, 2130903177, 2130903211, 2130903316, 2130903328, 
        2130903334 };
    
    public static final int RecyclerView_android_descendantFocusability = 1;
    
    public static final int RecyclerView_android_orientation = 0;
    
    public static final int RecyclerView_fastScrollEnabled = 2;
    
    public static final int RecyclerView_fastScrollHorizontalThumbDrawable = 3;
    
    public static final int RecyclerView_fastScrollHorizontalTrackDrawable = 4;
    
    public static final int RecyclerView_fastScrollVerticalThumbDrawable = 5;
    
    public static final int RecyclerView_fastScrollVerticalTrackDrawable = 6;
    
    public static final int RecyclerView_layoutManager = 7;
    
    public static final int RecyclerView_reverseLayout = 8;
    
    public static final int RecyclerView_spanCount = 9;
    
    public static final int RecyclerView_stackFromEnd = 10;
  }
}


/* Location:              C:\Users\mikel\Desktop\Projects\LEDStripController\HappyLighting_base-dex2jar.jar!\android\support\v7\recyclerview\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */