package android.support.cursoradapter;

public final class R {}


/* Location:              C:\Users\mikel\Desktop\Projects\LEDStripController\HappyLighting_base-dex2jar.jar!\android\support\cursoradapter\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */